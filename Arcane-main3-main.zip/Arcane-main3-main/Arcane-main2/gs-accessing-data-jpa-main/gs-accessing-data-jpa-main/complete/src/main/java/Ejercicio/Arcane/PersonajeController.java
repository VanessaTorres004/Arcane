package Ejercicio.Arcane;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/personajes")
public class PersonajeController {

    @Autowired
    private PersonajeRepository personajeRepository;

    @Autowired
    private AfiliacionRepository afiliacionRepository;

    @Autowired
    private UsoTecnologiaRepository usoTecnologiaRepository;

    @Autowired
    private RelacionRepository relacionRepository;

    // CRUD básico para Personaje
    @GetMapping
    public List<Personaje> getAllPersonajes() {
        return personajeRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Personaje> getPersonajeById(@PathVariable Long id) {
        return personajeRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Personaje> createPersonaje(@RequestBody Personaje personaje) {
        Personaje savedPersonaje = personajeRepository.save(personaje);
        return ResponseEntity.ok(savedPersonaje);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Personaje> updatePersonaje(@PathVariable Long id, @RequestBody Personaje personajeDetails) {
        return personajeRepository.findById(id)
                .map(personaje -> {
                    personaje.setNombre(personajeDetails.getNombre());
                    personaje.setOrigen(personajeDetails.getOrigen());
                    personaje.setRol(personajeDetails.getRol());
                    personaje.setAlineacion(personajeDetails.getAlineacion());
                    return ResponseEntity.ok(personajeRepository.save(personaje));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletePersonaje(@PathVariable Long id) {
        return personajeRepository.findById(id)
                .map(personaje -> {
                    // Eliminar dependencias primero
                    usoTecnologiaRepository.deleteByPersonajeId(id);
                    afiliacionRepository.deleteByPersonajeId(id);
                    relacionRepository.deleteByPersonajeId(id);

                    // Luego eliminar el personaje
                    personajeRepository.delete(personaje);
                    return ResponseEntity.ok().build();
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // Gestión de Afiliaciones
    @PostMapping("/{id}/afiliaciones")
    public ResponseEntity<Afiliacion> addAfiliacion(@PathVariable Long id, @RequestBody Afiliacion afiliacion) {
        return personajeRepository.findById(id)
                .map(personaje -> {
                    afiliacion.setPersonaje(personaje);
                    return ResponseEntity.ok(afiliacionRepository.save(afiliacion));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/{id}/afiliaciones")
    public ResponseEntity<List<Afiliacion>> getAfiliaciones(@PathVariable Long id) {
        return ResponseEntity.ok(afiliacionRepository.findByPersonajeId(id));
    }

    // Gestión de Tecnologías Usadas
    @PostMapping("/{id}/tecnologias")
    public ResponseEntity<UsoTecnologia> addTecnologia(@PathVariable Long id, @RequestBody UsoTecnologia usoTecnologia) {
        return personajeRepository.findById(id)
                .map(personaje -> {
                    usoTecnologia.setPersonaje(personaje);
                    return ResponseEntity.ok(usoTecnologiaRepository.save(usoTecnologia));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // Gestión de Relaciones
    @PostMapping("/{id}/relaciones")
    public ResponseEntity<Relacion> addRelacion(@PathVariable Long id, @RequestBody Relacion relacion) {
        return personajeRepository.findById(id)
                .map(personaje -> {
                    relacion.setPersonaje1(personaje);
                    return ResponseEntity.ok(relacionRepository.save(relacion));
                })
                .orElse(ResponseEntity.notFound().build());
    }
}