package Ejercicio.Arcane;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AfiliacionRepository extends JpaRepository<Afiliacion, Long> {

    // Opción 1: Usando la convención correcta de nombres
    List<Afiliacion> findByPersonajeIdPersonaje(Long idPersonaje);

    // Opción 2: Usando JPQL explícito (recomendado)
    @Query("SELECT a FROM Afiliacion a WHERE a.personaje.idPersonaje = :idPersonaje")
    List<Afiliacion> findByPersonajeId(@Param("idPersonaje") Long idPersonaje);

    @Query("SELECT a FROM Afiliacion a WHERE a.organizacion.idOrganizacion = :idOrganizacion")
    List<Afiliacion> findByOrganizacionId(@Param("idOrganizacion") Long idOrganizacion);

    @Modifying
    @Query("DELETE FROM Afiliacion a WHERE a.personaje.idPersonaje = :idPersonaje")
    void deleteByPersonajeId(@Param("idPersonaje") Long idPersonaje);

    @Modifying
    @Query("DELETE FROM Afiliacion a WHERE a.organizacion.idOrganizacion = :idOrganizacion")
    void deleteByOrganizacionId(@Param("idOrganizacion") Long idOrganizacion);
}