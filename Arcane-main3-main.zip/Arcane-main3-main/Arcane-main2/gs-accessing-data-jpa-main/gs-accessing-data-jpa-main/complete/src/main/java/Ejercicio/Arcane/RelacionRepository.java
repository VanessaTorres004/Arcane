package Ejercicio.Arcane;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RelacionRepository extends JpaRepository<Relacion, Long> {

    @Query("SELECT r FROM Relacion r WHERE r.personaje1.idPersonaje = :idPersonaje")
    List<Relacion> findByPersonaje1Id(@Param("idPersonaje") Long idPersonaje);

    @Query("SELECT r FROM Relacion r WHERE r.personaje2.idPersonaje = :idPersonaje")
    List<Relacion> findByPersonaje2Id(@Param("idPersonaje") Long idPersonaje);

    @Modifying
    @Query("DELETE FROM Relacion r WHERE r.personaje1.idPersonaje = :idPersonaje OR r.personaje2.idPersonaje = :idPersonaje")
    void deleteByPersonajeId(@Param("idPersonaje") Long idPersonaje);
}
