package Ejercicio.Arcane;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/organizaciones")
public class OrganizacionController {

    @Autowired
    private OrganizacionRepository organizacionRepository;

    @Autowired
    private AfiliacionRepository afiliacionRepository;

    // GET: Obtener todas las organizaciones
    @GetMapping
    public List<Organizacion> getAllOrganizaciones() {
        return organizacionRepository.findAll();
    }

    // GET: Buscar organizaciones por nombre
    @GetMapping("/buscar")
    public List<Organizacion> buscarPorNombre(@RequestParam String nombre) {
        return organizacionRepository.findByNombreContainingIgnoreCase(nombre);
    }

    // GET: Obtener organización por ID
    @GetMapping("/{id}")
    public ResponseEntity<Organizacion> getOrganizacionById(@PathVariable Long id) {
        Optional<Organizacion> organizacion = organizacionRepository.findById(id);
        return organizacion.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // POST: Crear nueva organización
    @PostMapping
    public ResponseEntity<Organizacion> createOrganizacion(@RequestBody Organizacion organizacion) {
        Organizacion nuevaOrganizacion = organizacionRepository.save(organizacion);
        return ResponseEntity.ok(nuevaOrganizacion);
    }

    // PUT: Actualizar organización
    @PutMapping("/{id}")
    public ResponseEntity<Organizacion> updateOrganizacion(@PathVariable Long id, @RequestBody Organizacion organizacionDetails) {
        return organizacionRepository.findById(id)
                .map(organizacion -> {
                    organizacion.setNombre(organizacionDetails.getNombre());
                    organizacion.setCiudadBase(organizacionDetails.getCiudadBase());
                    organizacion.setTipo(organizacionDetails.getTipo());
                    return ResponseEntity.ok(organizacionRepository.save(organizacion));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // DELETE: Eliminar organización
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteOrganizacion(@PathVariable Long id) {
        return organizacionRepository.findById(id)
                .map(organizacion -> {
                    // Primero eliminar afiliaciones relacionadas
                    afiliacionRepository.deleteByOrganizacionId(id);
                    // Luego eliminar la organización
                    organizacionRepository.delete(organizacion);
                    return ResponseEntity.ok().build();
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // GET: Obtener afiliaciones de una organización
    @GetMapping("/{id}/afiliaciones")
    public ResponseEntity<List<Afiliacion>> getAfiliaciones(@PathVariable Long id) {
        if (!organizacionRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(afiliacionRepository.findByOrganizacionId(id));
    }
}