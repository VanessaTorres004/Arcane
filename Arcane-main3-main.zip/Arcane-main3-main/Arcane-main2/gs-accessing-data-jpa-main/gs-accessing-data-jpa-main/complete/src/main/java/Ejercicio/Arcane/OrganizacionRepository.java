package Ejercicio.Arcane;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface OrganizacionRepository extends JpaRepository<Organizacion, Long> {
    // Puedes añadir métodos personalizados aquí si los necesitas
    List<Organizacion> findByNombreContainingIgnoreCase(String nombre);
}
