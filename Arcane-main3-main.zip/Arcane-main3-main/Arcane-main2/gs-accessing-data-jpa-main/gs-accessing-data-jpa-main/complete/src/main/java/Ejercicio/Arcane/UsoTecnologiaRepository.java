package Ejercicio.Arcane;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UsoTecnologiaRepository extends JpaRepository<UsoTecnologia, Long> {

    @Query("SELECT ut FROM UsoTecnologia ut WHERE ut.personaje.idPersonaje = :idPersonaje")
    List<UsoTecnologia> findByPersonajeId(@Param("idPersonaje") Long idPersonaje);

    @Modifying
    @Query("DELETE FROM UsoTecnologia ut WHERE ut.personaje.idPersonaje = :idPersonaje")
    void deleteByPersonajeId(@Param("idPersonaje") Long idPersonaje);
}